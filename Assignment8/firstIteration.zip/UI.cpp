#include "UI.h"


UI::UI(Service * service)
{
	this->service = service;
}

UI::~UI()
{
}
