#include "Service.h"
#include <iostream>
using namespace std;
Service::Service(Repository * repo)
{
	this->repo = repo;
}

Service::~Service()
{
}

vector<Human> Service::interpretCommand(vector<string> words)
{
	vector<Human> toReturn;
	if (words[0] == "mode") {
		if (words[1] == "A")
			this->mode = 'A';
		if (words[1] == "B")
			this->mode = 'B';
	}
	if (this->mode == 'A') {
		if (words[0] == "add") {
			Human newHuman(words[1], words[2], stoi(words[3]), words[4]);
			this->add(newHuman);
			return toReturn;
		}
		if (words[0] == "list") {
			return this->repo->getElements();
		}
		if (words[0] == "update") {
			Human newHuman(words[1], words[2], stoi(words[3]), words[4]);
			this->update(newHuman);
			return toReturn;
		}
		if (words[0] == "delete") {
			Human toDelete(words[1]);
			this->remove(toDelete);
			return toReturn;
		}
	}
	if (this->mode == 'B') {

	}
	return toReturn;
}

bool Service::add(Human toAdd)
{
	return this->repo->add(toAdd);
}

bool Service::remove(Human toRemove)
{
	return this->repo->remove(toRemove);
}

bool Service::update(Human toUpdate)
{
	return this->repo->update(toUpdate);
}
