#include "RepositoryHTML.h"

RepositoryHTML::RepositoryHTML(string path) : RepositoryTXT{path}
{
	this->path = path;
}

RepositoryHTML::~RepositoryHTML()
{
}

bool RepositoryHTML::load(string path)
{
	return true;
}

bool RepositoryHTML::save()
{
	ofstream file(this->path);

	file << "here should be the html";

	file.close();
	return true;
}
